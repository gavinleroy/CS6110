Assignment 2
============

Assignment 2 solution for Gavin Gray (u1040250)

University of Utah, Spring 2021 CS 6110

Files Included
--------------
* Asg2.pdf 
  Formal write-up for assignment questions.

* send\_money.py  
  A script to solve the Send More Money encoding puzzle using the z3-solver.

* just\_impl\_comp.pml
  A Promela program to check whether Justice implies Compassion, this
  program is used in conjuction with the question 1 write-up.

* comp\_impl\_just.pml
  A Promela program to check whether Compassion implies Justice, 
  this program is used in conjuctino with the question 2 write-up.

Cheers! :beers:

