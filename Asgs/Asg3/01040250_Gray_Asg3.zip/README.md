Assignment 3
============

Assignment 3 solution for Gavin Gray (u1040250)

University of Utah, Spring 2021 CS 6110

Files Included
--------------
* Asg3.pdf 
  Formal write-up for assignment questions.

* The code files representing the models for the Address Book tutorial in Chapter 2 of the Alloy bool.
  - addressbook1.als

  - addressbook2.als

  - addressbook3.als

Cheers! :beers:

