Assignment 6
============

Assignment 6 solution for Gavin Gray (u1040250)

University of Utah, Spring 2021 CS 6110

Files Included
--------------
* Asg6.pdf 
  Formal write-up for the assignment questions.

* q1.dfy
  The full Dafny code for problem 1.

* q2.dfy
  The full Dafny code for problem 2.

* q4.dfy
  The full Dafny code for problem 4.

Cheers! :beers:

