Assignment 4
============

Assignment 4 solution for Gavin Gray (u1040250)

University of Utah, Spring 2021 CS 6110

Files Included
--------------
* Asg4.pdf 
  Formal write-up for assignment questions.

* The code files representing the FOL statement checking in Alloy are
  - q3-1.als

  - q3-2.als

  - q3-3.als

Cheers! :beers:

